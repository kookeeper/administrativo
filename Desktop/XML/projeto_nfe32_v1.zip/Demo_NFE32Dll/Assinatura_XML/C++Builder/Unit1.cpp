//+------------------------------------------------------------------------------------+
//+TKS Software                                                                        +
//+Demo de Utiliza��o da Sintegra32dll.dll sem Banco de Dados                          +
//+                                                                                    +
//+ Demonstra e implementa a comunica��o entre o aplicativo e a dll para a             +
//+gera��o do arquivo magn�tico do SIntegra atrav�s da declara��o e chamada de         +
//+todas as fun��es e registros dispon�veis na vers�o.                                 +
//+                                                                                    +
//+ Para maiores informa��es consulte: http://igara.com.br/produto.php?cod_produto=114 +
//+                                                                                    +
//+------------------------------------------------------------------------------------+


#include <vcl.h>
#pragma hdrstop
#include <windows.h>
#include <iostream.h>
#include <conio.h>
#include "Unit1.h"

//------------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
AnsiString Path;
//------------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}

//------------------------------------------------------------------------------

typedef int (WINAPI*ifunc)(AnsiString t);

ifunc Func;

//------------------------------------------------------------------------------
              //assina arquivo XML
void __fastcall TForm1::Button1Click(TObject *Sender)
{

HINSTANCE hLib = LoadLibrary("assinaturaNFe32dll.dll");

if(hLib == NULL)
 {
  cout << "ERROR: A Dll nao pode ser chamada!" << endl;
  getch();
  return;
 }
 Path = Edit1->Text;
 Func = (ifunc)GetProcAddress((HMODULE)hLib,"fncAssinarXML_");
 Func(Path);

// FreeLibrary((HMODULE)hLib);
}


//------------------------------------------------------------------------------
           //abertura de arquivo XML
void __fastcall TForm1::Button12Click(TObject *Sender)
{
 if(OpenDialog1->Execute())
  Edit1->Text = OpenDialog1->FileName;
}




