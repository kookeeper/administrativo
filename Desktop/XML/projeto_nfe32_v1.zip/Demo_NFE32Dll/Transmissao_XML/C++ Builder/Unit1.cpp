//+------------------------------------------------------------------------------------+
//+TKS Software                                                                        +
//+Demo de Utiliza��o da Sintegra32dll.dll sem Banco de Dados                          +
//+                                                                                    +
//+ Demonstra e implementa a comunica��o entre o aplicativo e a dll para a             +
//+gera��o do arquivo magn�tico do SIntegra atrav�s da declara��o e chamada de         +
//+todas as fun��es e registros dispon�veis na vers�o.                                 +
//+                                                                                    +
//+ Para maiores informa��es consulte: http://igara.com.br/produto.php?cod_produto=114 +
//+                                                                                    +
//+------------------------------------------------------------------------------------+


#include <vcl.h>
#include <windows.h>
#include <iostream.h>
#include <conio.h>
#include <string>
#include <string.h>
#include "Unit1.h"
#pragma hdrstop
#include<stdio.h>
//------------------------------------------------------------------------------

#pragma package(smart_init)
#pragma resource "*.dfm"

TForm1 *Form1;
AnsiString Path;

//------------------------------------------------------------------------------

__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}

//------------------------------------------------------------------------------

typedef AnsiString (WINAPI*ifncNfeRecepcao)(AnsiString sXML, int iUF, int iTipo, AnsiString versao, AnsiString versaoDados);

ifncNfeRecepcao fncNfeRecepcao;

typedef AnsiString (WINAPI*ifncCadConsultaCadastro)(AnsiString sXML, int iUF, int iTipo, AnsiString versao, AnsiString versaoDados);

ifncCadConsultaCadastro fncCadConsultaCadastro;

typedef AnsiString (WINAPI*ifncNfeCancelamento)(AnsiString sXML, int iUF, int iTipo, AnsiString versao, AnsiString versaoDados);

ifncNfeCancelamento fncNfeCancelamento;

typedef AnsiString (WINAPI*ifncNfeConsulta)(AnsiString sXML, int iUF, int iTipo, AnsiString versao, AnsiString versaoDados);

ifncNfeConsulta fncNfeConsulta;

typedef AnsiString (WINAPI*ifncNfeInutilizacao)(AnsiString sXML, int iUF, int iTipo, AnsiString versao, AnsiString versaoDados);

ifncNfeInutilizacao fncNfeInutilizacao;

typedef AnsiString (WINAPI*ifncNfeRetRecepcao)(AnsiString sXML, int iUF, int iTipo, AnsiString versao, AnsiString versaoDados);

ifncNfeRetRecepcao fncNfeRetRecepcao;

typedef AnsiString (WINAPI*ifncNfeStatusServico)(AnsiString sXML, int iUF, int iTipo, AnsiString versao, AnsiString versaoDados);

ifncNfeStatusServico fncNfeStatusServico;

//------------------------------------------------------------------------------
           //transmiss�o de arquivo XML
void __fastcall TForm1::Button1Click(TObject *Sender)
{
 int  MyiUF   = ComboBox1->ItemIndex;
 int  MyiTipo = ComboBox2->ItemIndex;

 HINSTANCE hLib;
 hLib = LoadLibrary("transmissaoNFe32dll.dll");
 Path = Memo1->Lines->Text;
 Path = Path.SubString(4,Path.Length());
  switch(RadioGroup1->ItemIndex)
	{
         case 0:
          {
           fncNfeRecepcao = (ifncNfeRecepcao)GetProcAddress((HMODULE)hLib,"fncNfeRecepcao");
           fncNfeRecepcao   (Path, MyiUF, MyiTipo, "1.02", "1.12");
          }
           break;
         case 1:
          {
           fncCadConsultaCadastro = (ifncCadConsultaCadastro)GetProcAddress((HMODULE)hLib,"fncCadConsultaCadastro");
           fncCadConsultaCadastro   (Path, MyiUF, MyiTipo, "1.02", "1.01");
          }
           break;
         case 2:
          {
           fncNfeCancelamento = (ifncNfeCancelamento)GetProcAddress((HMODULE)hLib,"fncNfeCancelamento");
           fncNfeCancelamento   (Path, MyiUF, MyiTipo, "1.02", "1.07");
          }
           break;
         case 3:
          {
           fncNfeConsulta     = (ifncNfeConsulta)GetProcAddress((HMODULE)hLib,"fncNfeConsulta");
           fncNfeConsulta       (Path, MyiUF, MyiTipo, "1.02", "1.07");
          }
           break;
         case 4:
          {
           fncNfeInutilizacao = (ifncNfeInutilizacao)GetProcAddress((HMODULE)hLib,"fncNfeInutilizacao");
           fncNfeInutilizacao   (Path, MyiUF, MyiTipo, "1.02", "1.07");
          }
           break;
         case 5:
          {
           fncNfeRetRecepcao  = (ifncNfeRetRecepcao)GetProcAddress((HMODULE)hLib,"fncNfeRetRecepcao");
           fncNfeRetRecepcao    (Path, MyiUF, MyiTipo, "1.02", "1.11");
          }
           break;
         case 6:
          {
           fncNfeStatusServico  = (ifncNfeStatusServico)GetProcAddress(hLib,"fncNfeStatusServico");
           fncNfeStatusServico    (Path, MyiUF, MyiTipo, "1.02", "1.07");
          }
           break;
        }

 FreeLibrary(hLib);
}

//------------------------------------------------------------------------------
           //abertura de arquivo XML
void __fastcall TForm1::Button12Click(TObject *Sender)
{
 if(OpenDialog1->Execute())
  Memo1->Lines->LoadFromFile(OpenDialog1->FileName);
}

           //Salvamento de arquivo XML
void __fastcall TForm1::Button2Click(TObject *Sender)
{
 if(SaveDialog1->Execute())
  Memo3->Lines->SaveToFile(SaveDialog1->FileName);
}

