Instru��es para uso

1-Compilar o c�digo-fonte de Project1.dpr
2-Executar o c�digo compilado juntamente com as DLL's apresentadas:
	deskew.dll
	emgscan.dll
	FileBmp.dll
	FileTiff.dll
	ldf_jpm_logo.dll
	xxxDrv.dll

Este exemplo trabalha com formatos de arquivo BMP e TIF.

Para adotar outros formatos, basta salvar a imagem em formato BMP e
a partir do seu programa realizar a convers�o no formato de arquivo desejado.